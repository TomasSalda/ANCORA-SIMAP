import os
import subprocess

# 1. Crear directorio ssl y generar certificados si no existen
os.makedirs("ssl", exist_ok=True)
cert_path = os.path.join("ssl", "nginx.crt")
key_path = os.path.join("ssl", "nginx.key")

if not os.path.exists(cert_path) or not os.path.exists(key_path):
    print("🔐 Generando certificados SSL auto-firmados...")
    cmd = [
        "openssl", "req", "-x509", "-nodes", "-days", "365", "-newkey", "rsa:2048",
        "-keyout", key_path, "-out", cert_path,
        "-subj", "/C=CO/ST=Bogota/L=Bogota/O=AncoraSimap/CN=18.218.80.55"
    ]
    subprocess.run(cmd, check=True)
    print("✅ Certificados SSL creados en ./ssl/")
else:
    print("ℹ️ Certificados SSL ya existen en ./ssl/")

# 2. Generar docker-compose.yml
docker_compose_content = """version: '3.8'

services:
  ancora_simap_app:
    build:
      context: .
      dockerfile: Dockerfile
    container_name: ancora_simap_web
    restart: always
    ports:
      - "8501:8501"
    env_file:
      - .env
    volumes:
      - ./data:/app/data
      - ./ancora_simap_v6.db:/app/ancora_simap_v6.db
    networks:
      - ancora_net

  nginx_proxy:
    image: nginx:alpine
    container_name: ancora_simap_nginx
    restart: always
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/conf.d/default.conf:ro
      - ./ssl:/etc/nginx/ssl:ro
    depends_on:
      - ancora_simap_app
    networks:
      - ancora_net

networks:
  ancora_net:
    driver: bridge
"""

with open("docker-compose.yml", "w", encoding="utf-8") as f:
    f.write(docker_compose_content)
print("✅ docker-compose.yml actualizado correctamente.")

# 3. Generar nginx.conf
nginx_conf_content = """server {
    listen 80;
    server_name _;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl;
    server_name _;

    ssl_certificate /etc/nginx/ssl/nginx.crt;
    ssl_certificate_key /etc/nginx/ssl/nginx.key;

    location / {
        proxy_pass http://ancora_simap_app:8501;
        proxy_http_version 1.1;

        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        proxy_read_timeout 86400s;
        proxy_send_timeout 86400s;
        client_max_body_size 50M;
    }
}
"""

with open("nginx.conf", "w", encoding="utf-8") as f:
    f.write(nginx_conf_content)
print("✅ nginx.conf actualizado correctamente.")

print("\n🚀 Configuración SSL lista. Puedes ejecutar ahora:")
print("sudo docker compose down && sudo docker compose up -d")
